<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style/main.css">
    <title>Forum</title>
</head>
<body>
    <header>
        <div id="main_img">
            </div>
        <div id = "header_menu">
            <div class="container">
                <ul>
                    <li class="test"><a><div id="img_prof"></div></a></li>
                    <li class="test" id="Username_a"><a id="">Username</a></li>
                    <li class="test" style="float: left; padding: 0;"><div id="logo_header"></div></li>
                </ul>
            </div>
        </div>
    </header>
    <main>
<div class="container">  
    <div  id="white_block">
    <div id="registration_page">
        <form method="post" action="register.php">

            <?php include('errors.php'); ?>
    
			<ul class="Login_list">
                <label>Name</label>
				<li>  <input type="text"  placeholder="Your Name"name="name" ></li>
         
                <label>Email</label>
               <li>  <input type="email" placeholder="Your Email" name="email"> </li>

                <label>Password</label>
				<li>  <input type="password" placeholder="....." name="password_1"></li>

                <label>Confirm password</label>
				<li>  <input type="password" placeholder="....." name="password_2"></li> 

                <label>Country</label>
               <li> <input type="text" placeholder="Your Country" name="country"> </li>
			   <li> <button type="submit" class="btn" name="reg_user">Register</button>  </li>
			   <p>
                Already a member? <a href="login.php">Sign in</a>
               </p>
			   </ul>
          
        </form>
	</div>    
	</div>
</main>
        
</body>
</html>